import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  template: `
    <p>
      KT
    </p>
  `,
  styles: [
  ]
})
export class FirstComponent {

}
