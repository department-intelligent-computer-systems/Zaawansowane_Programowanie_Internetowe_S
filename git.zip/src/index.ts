function hello() {
    console.log("Witaj w swiecie Typescript.")
}

hello();
